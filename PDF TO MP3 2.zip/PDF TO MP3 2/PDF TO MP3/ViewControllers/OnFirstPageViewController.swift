//
//  OnFirstPageViewController.swift
//  PDF TO MP3
//
//  Created by SAIL L1 on 29/01/25.
//

import UIKit

class OnFirstPageViewController: UIViewController {

    @IBOutlet weak var getStartedButton: UIButton! // Corrected IBOutlet

    override func viewDidLoad() {
        super.viewDidLoad()
        
        getStartedButton.layer.cornerRadius = 10
        getStartedButton.clipsToBounds = true
    }

    @IBAction func getStartedTapped(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "OnBoardingViewController") as! OnBoardingViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
