//
//  MusicViewController.swift
//  PDF TO MP3
//
//  Created by SAIL L1 on 04/02/25.
//

import UIKit
import AVFoundation

class MusicViewController: UIViewController {
    var audioPlayer: AVPlayer?
    var playerItem: AVPlayerItem?
    var timer: Timer?
    
    
    
    
    @IBOutlet weak var progressView: UIProgressView!
    

    @IBOutlet weak var audioDisplayLabel: UILabel!
    @IBOutlet weak var allBtnView: UIView!
    @IBOutlet weak var forwardBtn: UIButton!
    @IBOutlet weak var backwardBtn: UIButton!
    @IBOutlet weak var totalTimeLabel: UILabel!
    @IBOutlet weak var currentTimeLabel: UILabel!
  
    @IBOutlet weak var Btn: UIButton!

    var audioFilesResponse: FetchAudioModel?
    var audioUrl: String?
    var isFromList: Bool = false
    var audioTitle: String?
    
    
    var formattedTime  = String()
    var count:Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        progressView.progress = 0.0

      
        allBtnView.layer.cornerRadius = 20
        allBtnView.layer.masksToBounds = true

        audioDisplayLabel.text = audioTitle ?? "Unknown Audio"
        
        
     

      

        if isFromList {
           
            
            downloadAndGetDuration(from: audioUrl ?? "") { [self] duration in
                if let duration = duration {
                    let minutes = Int(duration) / 60
                let seconds = duration.truncatingRemainder(dividingBy: 60.0)
                            
                formattedTime = String(format: "%.0f.%.0f", Float(minutes), seconds)
                    print("Total duration: \(minutes) min (\(seconds) sec)")
                    
                   
                    totalTimeLabel.text = formattedTime
                    
                    playAudioFromURL(audioUrl ?? "")
                } else {
                    print("Failed to get duration")
                }
            }
           
            
            
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.fetchAudioFiles()
            }
        }
        
       

        
        print("Audio title in viewDidLoad: \(audioTitle ?? "nil")")
    }

    
   
        
       
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let audioFiles = self.audioFilesResponse?.data[1].mp3Files {
            let selectedAudio = audioFiles[indexPath.row]

            let musicVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MusicViewController") as! MusicViewController
            musicVC.isFromList = true
            musicVC.audioUrl = "https://q694t46c-8000.inc1.devtunnels.ms/media/\(selectedAudio.mp3File ?? "")"
            musicVC.audioTitle = selectedAudio.title
            print("Selected title: \(selectedAudio.title)")

            self.navigationController?.pushViewController(musicVC, animated: true)
        }
    }

    private func fetchAudioFiles() {
        guard let userId = Constants.loginDataResponse?.id else { return }
        let param = ["id": userId]
        self.view.startLoader()

        APIHandler.shared.postAPIValues(type: FetchAudioModel.self, apiUrl: APIList.fileslist, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                self.view.stopLoader()
                switch result {
                case .success(let response):
                    if response.status {
                        self.audioFilesResponse = response
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.filterSelectedAudioFiles()
                        }
                    }
                case .failure(let err):
                    print(err)
                }
            }
        }
    }

    private func filterSelectedAudioFiles() {
        DispatchQueue.main.async {
            guard let lastConvertPdfId = Constants.lastUploadedPDF?.data.first?.id,
                  let data = self.audioFilesResponse?.data[1] else { return }

            let audioData = data.mp3Files?.last
            if let url = audioData?.mp3File, let title = audioData?.title {
                self.audioUrl = "https://q694t46c-8000.inc1.devtunnels.ms/media/\(url)"
                self.audioTitle = title
                self.audioDisplayLabel.text = title
                self.playAudioFromURL(self.audioUrl ?? "")
                print("Selected Audio Title: \(title)")
            } else {
                print("No matching audio file found")
            }
        }
    }

    @IBAction func BtnTapped(_ sender: Any) {
        if let player = audioPlayer {
            if player.timeControlStatus == .playing {
                player.pause()
                Btn.setImage(UIImage(named: "icons8-play-30"), for: .normal)
                timer?.invalidate()
            } else {
                player.play()
                Btn.setImage(UIImage(named: "icons8-pause-48 1"), for: .normal)
                startTimer()
            }
        } else if let urlString = audioUrl {
            playAudioFromURL(urlString)
        } else {
            print("No audio URL available")
        }
    }

    func playAudioFromURL(_ urlString: String) {
        guard let url = URL(string: urlString) else {
            print("Invalid URL: \(urlString)")
            return
        }

        playerItem = AVPlayerItem(url: url)
        audioPlayer = AVPlayer(playerItem: playerItem)

        // Observe when the audio finishes
        NotificationCenter.default.addObserver(self, selector: #selector(audioDidFinishPlaying), name: .AVPlayerItemDidPlayToEndTime, object: playerItem)

        audioPlayer?.play()
        Btn.setImage(UIImage(named: "icons8-pause-48 1"), for: .normal)
        startTimer()
    }

    @objc func audioDidFinishPlaying() {
        print("Audio Finished Playing")
        audioPlayer?.seek(to: CMTime.zero)
        Btn.setImage(UIImage(named: "icons8-play-30"), for: .normal)
    }

    @IBAction func backBtnTapped(_ sender: Any) {
        if let player = audioPlayer {
            let currentTime = CMTimeGetSeconds(player.currentTime()) - 10
            let newTime = CMTimeMakeWithSeconds(max(currentTime, 0), preferredTimescale: 1)
            player.seek(to: newTime)
        }
    }

    @IBAction func forwardBtnTapped(_ sender: Any) {
        if let player = audioPlayer, let duration = player.currentItem?.duration.seconds {
            let currentTime = CMTimeGetSeconds(player.currentTime()) + 10
            let newTime = CMTimeMakeWithSeconds(min(currentTime, duration), preferredTimescale: 1)
            player.seek(to: newTime)
        }
    }

   
    
    func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateSlider), userInfo: nil, repeats: true)

        audioPlayer?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 1), queue: .main) { [weak self] time in
            guard let self = self else { return }
            
            count += 1
            progressView.progress = Float(count) / (4.0 * 100)
            
           
           
            print("===>> static value:\(Float(count) / ((4.0 * 100)))")
           
            print("===>> dynamic value:\(Float(count) / ((Float(formattedTime) ?? 0.0 * 100)))")
//            DispatchQueue.main.async {
//                self.currentTimeLabel.text = self.formatTime(time.seconds)
//                
//                self.count = time.seconds + 1
//                
//                self.progressView.progress = Float(self.count) / 4.3 * 100
//                
//                let val = Float(self.count / (Double(self.formattedTime) ?? 0.0))
//                
//                self.slider.value = val
//                print(Float(time.seconds))
//            }
        }
    }

    @objc func updateSlider() {
        guard let player = audioPlayer else { return }
        DispatchQueue.main.async {
            let currentTime = CMTimeGetSeconds(player.currentTime())
            self.currentTimeLabel.text = self.formatTime(currentTime)
           
        }
    }

    @objc func sliderChanged(_ sender: UISlider) {
        let newTime = CMTimeMakeWithSeconds(Float64(sender.value), preferredTimescale: 1)
        audioPlayer?.seek(to: newTime)
        DispatchQueue.main.async {
            self.currentTimeLabel.text = self.formatTime(Double(sender.value))
        }
    }

    func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    
    func downloadAndGetDuration(from urlString: String, completion: @escaping (Double?) -> Void) {
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            completion(nil)
            return
        }

        let task = URLSession.shared.downloadTask(with: url) { localURL, _, error in
            if let localURL = localURL {
                print("Downloaded file location: \(localURL.absoluteString)")

                let fileManager = FileManager.default
                let documentsPath = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
                let destinationURL = documentsPath.appendingPathComponent("temp_audio.mp3")

                // Remove any existing file at destination
                try? fileManager.removeItem(at: destinationURL)

                do {
                    try fileManager.moveItem(at: localURL, to: destinationURL)
                    print("File moved to: \(destinationURL.absoluteString)")
                } catch {
                    print("File move error: \(error.localizedDescription)")
                    DispatchQueue.main.async { completion(nil) }
                    return
                }

                let asset = AVURLAsset(url: destinationURL)
                asset.loadValuesAsynchronously(forKeys: ["duration"]) {
                    var error: NSError?
                    let status = asset.statusOfValue(forKey: "duration", error: &error)

                    if status == .loaded {
                        let duration = CMTimeGetSeconds(asset.duration)
                        DispatchQueue.main.async { completion(duration.isFinite ? duration : nil) }
                    } else {
                        print("Failed to load duration: \(error?.localizedDescription ?? "Unknown error")")
                        DispatchQueue.main.async { completion(nil) }
                    }
                }
            } else {
                print("Download failed: \(error?.localizedDescription ?? "Unknown error")")
                DispatchQueue.main.async { completion(nil) }
            }
        }

        task.resume()
    }
}
